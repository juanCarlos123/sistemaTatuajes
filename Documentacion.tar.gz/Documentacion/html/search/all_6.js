var searchData=
[
  ['main',['main',['../d6/d29/principal_8c.html#abbc50c23c5192bfa8579c0c06a87fcd9',1,'principal.c']]],
  ['mainpage_2edox',['mainpage.dox',['../d5/d4d/mainpage_8dox.html',1,'']]],
  ['menu',['menu',['../db/d09/datos_8h.html#ad16e5e62f3579a7048e6b981b172885e',1,'menu(void):&#160;menu.c'],['../d2/d0a/menu_8c.html#ad16e5e62f3579a7048e6b981b172885e',1,'menu(void):&#160;menu.c']]],
  ['menu_2ec',['menu.c',['../d2/d0a/menu_8c.html',1,'']]],
  ['modificainventario',['modificaInventario',['../db/d09/datos_8h.html#af91ffe71df436e86e49d6ea852fac1f2',1,'modificaInventario(Inventario *, int32_t):&#160;inventario.c'],['../d4/de4/inventario_8c.html#a0ca7d01312a5b1e43bc14271caaee285',1,'modificaInventario(Inventario *inv, int32_t p):&#160;inventario.c']]]
];
