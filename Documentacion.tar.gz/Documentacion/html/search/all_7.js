var searchData=
[
  ['nombreproducto',['nombreProducto',['../df/d0e/structinventario.html#a5b3965bf83a5c2f4d4046f1cb778e182',1,'inventario']]]
];
