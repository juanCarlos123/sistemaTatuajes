var searchData=
[
  ['pedirdato',['pedirDato',['../db/d09/datos_8h.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c'],['../d2/d0a/menu_8c.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c']]],
  ['precio',['precio',['../df/d0e/structinventario.html#acf3fc4eaa060ab3bb3fc14163068b5e0',1,'inventario']]],
  ['principal_2ec',['principal.c',['../d6/d29/principal_8c.html',1,'']]]
];
