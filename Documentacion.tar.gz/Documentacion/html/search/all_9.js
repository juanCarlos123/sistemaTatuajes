var searchData=
[
  ['quitainventario',['quitaInventario',['../db/d09/datos_8h.html#ab2f1773c99ec3dc3e2c881024f534e35',1,'quitaInventario(Inventario *, int32_t):&#160;inventario.c'],['../d4/de4/inventario_8c.html#ae5bcf18b29f00082b7a6f8c914be29a0',1,'quitaInventario(Inventario *inv, int32_t p):&#160;inventario.c']]]
];
