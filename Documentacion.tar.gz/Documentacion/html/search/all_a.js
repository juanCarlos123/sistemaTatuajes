var searchData=
[
  ['readme',['README',['../d0/d30/md_README.html',1,'']]],
  ['readme_2emd',['README.md',['../da/ddd/README_8md.html',1,'']]],
  ['registro',['REGISTRO',['../db/d09/datos_8h.html#a38e152ed2e3da7891e43642057967935',1,'datos.h']]],
  ['registro_2ec',['registro.c',['../d9/dc9/registro_8c.html',1,'']]],
  ['revisainventario',['revisaInventario',['../db/d09/datos_8h.html#aff755767b40a1596c15f454942ccdab9',1,'revisaInventario(Inventario *, int32_t):&#160;inventario.c'],['../d4/de4/inventario_8c.html#afedc41ce641076ec371355bcc4068b25',1,'revisaInventario(Inventario *inv, int32_t p):&#160;inventario.c']]],
  ['revisaregistro',['revisaRegistro',['../db/d09/datos_8h.html#a6e32ce01c20757edd2bf471b5936ae4f',1,'revisaRegistro(Servicio *, int32_t):&#160;registro.c'],['../d9/dc9/registro_8c.html#a7c6381cbd41bc13aff787287bdb89fdf',1,'revisaRegistro(Servicio *serv, int32_t s):&#160;registro.c']]]
];
