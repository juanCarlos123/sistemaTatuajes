var searchData=
[
  ['vendedor',['vendedor',['../d8/d1b/structservicio.html#ad81144d327248397886deb4d0435ead0',1,'servicio']]]
];
