var searchData=
[
  ['winventario',['wInventario',['../db/d09/datos_8h.html#a49e53e5dd8b3b0fcf28520f7826be3fd',1,'wInventario(void *):&#160;hilos.c'],['../d0/da4/hilos_8c.html#aeb3244531317b1d2d612074a64123f2a',1,'wInventario(void *args):&#160;hilos.c']]],
  ['wservicio',['wServicio',['../db/d09/datos_8h.html#a11f27b462d56d5aba83720c467a16c5e',1,'wServicio(void *):&#160;hilos.c'],['../d0/da4/hilos_8c.html#a17f049066fcaf1c3b808b3b2badbcae1',1,'wServicio(void *args):&#160;hilos.c']]]
];
