var searchData=
[
  ['inventario',['inventario',['../df/d0e/structinventario.html',1,'']]]
];
