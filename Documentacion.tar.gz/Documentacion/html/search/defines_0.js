var searchData=
[
  ['inventario',['INVENTARIO',['../db/d09/datos_8h.html#a6c7294b2c5f3d4ef8cca7493bd9b8883',1,'datos.h']]]
];
