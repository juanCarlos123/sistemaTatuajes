var searchData=
[
  ['inventario_2ec',['inventario.c',['../d4/de4/inventario_8c.html',1,'']]]
];
