var searchData=
[
  ['readme_2emd',['README.md',['../da/ddd/README_8md.html',1,'']]],
  ['registro_2ec',['registro.c',['../d9/dc9/registro_8c.html',1,'']]]
];
