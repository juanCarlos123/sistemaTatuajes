var searchData=
[
  ['pedirdato',['pedirDato',['../db/d09/datos_8h.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c'],['../d2/d0a/menu_8c.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c']]]
];
