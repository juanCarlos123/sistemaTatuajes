var searchData=
[
  ['inventario',['Inventario',['../db/d09/datos_8h.html#a9f02fe20a86118557d1ce1b2ef1042ce',1,'datos.h']]]
];
