var searchData=
[
  ['semantica',['semantica',['../d5/d4d/mainpage_8dox.html#a7f67bebc1771f55d429e8c956cb7de0b',1,'mainpage.dox']]],
  ['servicio',['servicio',['../d8/d1b/structservicio.html#af113bd56e546d39be5870d47acbde1b5',1,'servicio']]],
  ['size',['size',['../df/d0e/structinventario.html#aef20417d04aa81761765e9b89f56191b',1,'inventario::size()'],['../d8/d1b/structservicio.html#a899c8282e19efc27f38b61beb3ef9747',1,'servicio::size()']]]
];
