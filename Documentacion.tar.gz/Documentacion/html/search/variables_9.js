var searchData=
[
  ['tienda',['tienda',['../df/d0e/structinventario.html#a00fa453ee2755aebcd34863b1d127082',1,'inventario::tienda()'],['../d8/d1b/structservicio.html#a9d81f28b3a8e01cf2e94784b6dfa6369',1,'servicio::tienda()']]],
  ['tipo',['tipo',['../d5/d4d/mainpage_8dox.html#a8a21ae5c93cf9802030580a7894ad426',1,'mainpage.dox']]],
  ['total',['total',['../d8/d1b/structservicio.html#a4ee34fb6f21535b0bfe35fef9e1b7ad2',1,'servicio']]]
];
