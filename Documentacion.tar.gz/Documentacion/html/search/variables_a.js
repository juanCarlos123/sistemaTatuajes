var searchData=
[
  ['vendedor',['vendedor',['../d8/d1b/structservicio.html#ad81144d327248397886deb4d0435ead0',1,'servicio::vendedor()'],['../d5/d4d/mainpage_8dox.html#a3e6fcef6f270445ca4c03d9c40852f39',1,'vendedor():&#160;mainpage.dox']]]
];
