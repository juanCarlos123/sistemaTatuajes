var searchData=
[
  ['escribirdatos',['escribirDatos',['../datos_8h.html#a13edfea824787a62154f15ceadbf18e4',1,'escribirDatos(Inventario *, Servicio *):&#160;salida.c'],['../salida_8c.html#a2731059a15815141548fcfbac01d6ce1',1,'escribirDatos(Inventario *inv, Servicio *serv):&#160;salida.c']]]
];
