var searchData=
[
  ['nombreproducto',['nombreProducto',['../structinventario.html#a5b3965bf83a5c2f4d4046f1cb778e182',1,'inventario']]]
];
