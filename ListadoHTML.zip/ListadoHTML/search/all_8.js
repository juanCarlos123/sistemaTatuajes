var searchData=
[
  ['pedirdato',['pedirDato',['../datos_8h.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c'],['../menu_8c.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c']]],
  ['precio',['precio',['../structinventario.html#acf3fc4eaa060ab3bb3fc14163068b5e0',1,'inventario']]],
  ['principal_2ec',['principal.c',['../principal_8c.html',1,'']]]
];
