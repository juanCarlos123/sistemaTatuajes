var searchData=
[
  ['tienda',['tienda',['../structinventario.html#a00fa453ee2755aebcd34863b1d127082',1,'inventario::tienda()'],['../structservicio.html#a9d81f28b3a8e01cf2e94784b6dfa6369',1,'servicio::tienda()']]],
  ['total',['total',['../structservicio.html#a4ee34fb6f21535b0bfe35fef9e1b7ad2',1,'servicio']]]
];
