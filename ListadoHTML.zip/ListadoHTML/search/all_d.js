var searchData=
[
  ['vendedor',['vendedor',['../structservicio.html#ad81144d327248397886deb4d0435ead0',1,'servicio']]]
];
