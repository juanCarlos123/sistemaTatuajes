var searchData=
[
  ['inventario',['inventario',['../structinventario.html',1,'']]]
];
