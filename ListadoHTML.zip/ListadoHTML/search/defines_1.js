var searchData=
[
  ['registro',['REGISTRO',['../datos_8h.html#a38e152ed2e3da7891e43642057967935',1,'datos.h']]]
];
