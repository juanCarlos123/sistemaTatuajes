var searchData=
[
  ['inventario_2ec',['inventario.c',['../inventario_8c.html',1,'']]]
];
