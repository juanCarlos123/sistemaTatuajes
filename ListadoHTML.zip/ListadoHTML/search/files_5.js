var searchData=
[
  ['registro_2ec',['registro.c',['../registro_8c.html',1,'']]]
];
