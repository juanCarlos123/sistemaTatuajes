var searchData=
[
  ['salida_2ec',['salida.c',['../salida_8c.html',1,'']]]
];
