var searchData=
[
  ['ctrlc',['ctrlc',['../datos_8h.html#a198afd1774cddb311dce0be112d3d152',1,'ctrlc(int):&#160;datos.h'],['../principal_8c.html#a6b0cbf8a6792e8a0cf994072d0c684f2',1,'ctrlc(int32_t sign):&#160;principal.c']]],
  ['cuentainventario',['cuentaInventario',['../datos_8h.html#a9b29005f2ed307507a2980ba9469e227',1,'cuentaInventario(void *):&#160;hilos.c'],['../hilos_8c.html#a79dd27f255492093ee7a6c3e21071fe0',1,'cuentaInventario(void *p):&#160;hilos.c']]],
  ['cuentaregistro',['cuentaRegistro',['../datos_8h.html#ad9e7dbd3926f99b5bc130c35d52d0cb3',1,'cuentaRegistro(void *):&#160;hilos.c'],['../hilos_8c.html#ab1aebbc2245a107b448b31a131078475',1,'cuentaRegistro(void *r):&#160;hilos.c']]]
];
