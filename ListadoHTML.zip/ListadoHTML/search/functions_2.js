var searchData=
[
  ['ingresainventario',['ingresaInventario',['../datos_8h.html#a6f8b0f9d8a235b6cdab917c9d9f4f2cf',1,'ingresaInventario(Inventario *, int32_t):&#160;inventario.c'],['../inventario_8c.html#ae27d24b4f1ee3934ce71f33d055ada2b',1,'ingresaInventario(Inventario *inv, int32_t p):&#160;inventario.c']]],
  ['ingresaregistro',['ingresaRegistro',['../datos_8h.html#ac903baef492eb38c65502f68a726987a',1,'ingresaRegistro(Servicio *, int32_t):&#160;registro.c'],['../registro_8c.html#a71eeb5f2e1b46bd8b54c06bf3f914613',1,'ingresaRegistro(Servicio *serv, int32_t s):&#160;registro.c']]],
  ['inicio',['inicio',['../datos_8h.html#a0633761a5abb4ca1d7911b2c09b8494b',1,'inicio(void):&#160;menu.c'],['../menu_8c.html#a0633761a5abb4ca1d7911b2c09b8494b',1,'inicio(void):&#160;menu.c']]]
];
