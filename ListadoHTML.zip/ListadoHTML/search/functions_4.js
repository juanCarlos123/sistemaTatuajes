var searchData=
[
  ['pedirdato',['pedirDato',['../datos_8h.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c'],['../menu_8c.html#a5661e1ddd023204391185ddd30fc9ed2',1,'pedirDato(void):&#160;menu.c']]]
];
