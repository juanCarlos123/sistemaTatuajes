var searchData=
[
  ['revisainventario',['revisaInventario',['../datos_8h.html#aff755767b40a1596c15f454942ccdab9',1,'revisaInventario(Inventario *, int32_t):&#160;inventario.c'],['../inventario_8c.html#afedc41ce641076ec371355bcc4068b25',1,'revisaInventario(Inventario *inv, int32_t p):&#160;inventario.c']]],
  ['revisaregistro',['revisaRegistro',['../datos_8h.html#a6e32ce01c20757edd2bf471b5936ae4f',1,'revisaRegistro(Servicio *, int32_t):&#160;registro.c'],['../registro_8c.html#a7c6381cbd41bc13aff787287bdb89fdf',1,'revisaRegistro(Servicio *serv, int32_t s):&#160;registro.c']]]
];
