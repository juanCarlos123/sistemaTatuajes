var searchData=
[
  ['precio',['precio',['../structinventario.html#acf3fc4eaa060ab3bb3fc14163068b5e0',1,'inventario']]]
];
